/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   handle_paths.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qacjl <qacjl@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:26:54 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/27 16:27:15 by qacjl            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	exec_cd(t_shell *shell, t_prompt *prompt)
{
	char	buffer[PATH_MAX];

	if (chdir(prompt->strs[1]) != 0)
		ft_printf("cd: no such file or directory: %s\n",
			prompt->strs[1]);
	else
	{
		if (ft_strcmp(shell->old_pwd, shell->pwd) != 0)
		{
			free(shell->old_pwd);
			shell->old_pwd = ft_strdup(shell->pwd);
		}
		getcwd(buffer, PATH_MAX);
		free(shell->pwd);
		shell->pwd = ft_strdup(buffer);
	}
	update_paths(shell, shell->env_lines);
	update_paths_export(shell, shell->export_lines);
}

void	update_paths(t_shell *shell, t_list *lst)
{
	t_list	*temp;

	temp = lst;
	while (temp != NULL)
	{
		if (ft_strncmp(temp->content, "OLDPWD=", 7) == 0)
		{
			free(temp->content);
			temp->content = ft_strjoin("OLDPWD=", shell->old_pwd);
		}
		else if (ft_strncmp(temp->content, "PWD=", 4) == 0)
		{
			free(temp->content);
			temp->content = ft_strjoin("PWD=", shell->pwd);
		}
		temp = temp->next;
	}
}

void	update_paths_export(t_shell *shell, t_list *lst)
{
	t_list	*temp;
	char	*line;

	temp = lst;
	line = NULL;
	while (temp != NULL)
	{
		if (ft_strncmp(temp->content, "OLDPWD=", 7) == 0)
		{
			free(temp->content);
			line = ft_strjoin("OLDPWD=", shell->old_pwd);
			temp->content = copy_line_with_quotes(line);
			free(line);
		}
		else if (ft_strncmp(temp->content, "PWD=", 4) == 0)
		{
			free(temp->content);
			line = ft_strjoin("PWD=", shell->pwd);
			temp->content = copy_line_with_quotes(line);
			free(line);
		}
		temp = temp->next;
	}
}

/* Recherche le chemin complet de la commande */
char	*get_command_path(char *cmd, char **env)
{
	char		*path_line;
	char		**paths;
	char		*full_path;
	int			i;

	if (ft_strchr(cmd, '/') != NULL)
		return (ft_strdup(cmd));
	path_line = find_path_line(env);
	paths = ft_split(path_line, ':');
	free(path_line);
	i = 0;
	full_path = NULL;
	while (paths[i] != NULL)
	{
		full_path = ft_strjoin(paths[i], cmd);
		if (access(full_path, F_OK | X_OK) == 0)
			break ;
		free(full_path);
		full_path = NULL;
		i = i + 1;
	}
	free_2d_array(paths);
	if (full_path == NULL)
		full_path = ft_strdup(cmd);
	return (full_path);
}
