/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   string_utils.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qacjl <qacjl@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:36:52 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/27 16:36:53 by qacjl            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

/* ************************************************************************** */
/*                           STRING_UTILS.C                                 */
/* ************************************************************************** */

#include "minishell.h"

char	*ft_strcpy(char *dest, const char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i = i + 1;
	}
	dest[i] = '\0';
	return (dest);
}

int	ft_strcmp(const char *s1, const char *s2)
{
	int	i;

	i = 0;
	while (s1[i] != '\0' && s1[i] == s2[i])
	{
		i = i + 1;
	}
	return (s1[i] - s2[i]);
}

int	count_occurrences(const char *cmd_line, int to_find)
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	while (cmd_line[i] != '\0')
	{
		if (cmd_line[i] == to_find)
			count = count + 1;
		i = i + 1;
	}
	return (count);
}

int	count_words(const char *str)
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	if (str[0] != '\0' && str[0] != ' ')
	{
		i = i + 1;
		count = count + 1;
	}
	while (str[i] != '\0')
	{
		if (str[i] == ' ' &&
		    (str[i + 1] != '\0' && str[i + 1] != ' '))
			count = count + 1;
		i = i + 1;
	}
	return (count);
}

char	*ft_strndup(const char *src, size_t n)
{
	size_t	i;
	char	*dest;

	i = 0;
	dest = malloc(sizeof(char) * (n + 1));
	if (dest == NULL)
		return (NULL);
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i = i + 1;
	}
	dest[i] = '\0';
	return (dest);
}
