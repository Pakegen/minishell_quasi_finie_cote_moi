/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   exec_unset.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qacjl <qacjl@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:24:14 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/27 16:24:22 by qacjl            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	exec_unset(t_shell *shell, t_prompt *prompt)
{
	int	i;

	i = 1;
	while (prompt->strs[i] != NULL)
	{
		find_env_line(shell, prompt->strs[i], &shell->env_lines);
		find_env_line(shell, prompt->strs[i], &shell->export_lines);
		i = i + 1;
	}
}

void	find_env_line(t_shell *shell, char *var, t_list **lst)
{
	int		size;
	t_list	*name;
	t_list	*temp;

	temp = *lst;
	name = shell->vars;
	while (name != NULL &&
		   ft_strcmp(name->content, var) != 0)
	{
		name = name->next;
	}
	if (name != NULL && ft_strcmp(name->content, "_") != 0)
	{
		size = ft_strlen(name->content);
		while (temp != NULL &&
			   ft_strncmp(name->content, temp->content, size) != 0)
		{
			temp = temp->next;
		}
		if (temp != NULL)
			remove_line(lst, temp->content);
	}
}

void	remove_line(t_list **lst, char *line)
{
	t_list	*next_one;
	t_list	*temp;

	temp = *lst;
	if (ft_strcmp(temp->content, line) == 0)
	{
		*lst = temp->next;
		free(temp->content);
		free(temp);
		return ;
	}
	while (temp != NULL)
	{
		if (temp->next != NULL &&
			ft_strcmp(temp->next->content, line) == 0)
		{
			next_one = temp->next;
			temp->next = temp->next->next;
			free(next_one->content);
			free(next_one);
			return ;
		}
		temp = temp->next;
	}
}
