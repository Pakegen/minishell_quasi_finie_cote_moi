/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   history.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qacjl <qacjl@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:28:20 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/27 16:29:00 by qacjl            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

void	display_history(void)
{
	HIST_ENTRY	**history_list;
	int			i;

	history_list = history_get_history_state()->entries;
	i = 0;
	if (history_list != NULL)
	{
		while (history_list[i] != NULL)
		{
			ft_printf("%d  %s\n", i + 1, history_list[i]->line);
			i = i + 1;
		}
	}
}

void	verif_history(const char *input)
{
	if (ft_strcmp(input, "history") == 0)
		display_history();
	else
		ft_printf("Exécution de la commande : %s\n", input);
}

