/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   check_command_line.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: qacjl <qacjl@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/27 16:19:28 by qacjl             #+#    #+#             */
/*   Updated: 2025/02/27 16:20:07 by qacjl            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "minishell.h"

int	count_quotes(const char *cmd_line)
{
	int	i;
	int	count;

	i = 0;
	count = 0;
	while (cmd_line[i] != '\0')
	{
		if (cmd_line[i] == '\'' || cmd_line[i] == '"')
			break ;
		i = i + 1;
	}
	if (cmd_line[i] == '\'')
		count = count_occurrences(cmd_line, '\'');
	else if (cmd_line[i] == '"')
		count = count_occurrences(cmd_line, '"');
	return (count);
}

int	check_path_validity(char *cmd)
{
	if (access(cmd, F_OK | X_OK) == -1 ||
	    ft_strlen(ft_strrchr(cmd, '/') + 1) == 0)
		return (0);
	return (1);
}

int	existing_command(char **paths, char *cmd)
{
	int		i;
	int		result;
	char	*cmd_path;

	i = 0;
	if (cmd == NULL)
		return (0);
	if (ft_strchr(cmd, '/') != NULL)
		return (check_path_validity(cmd));
	while (paths[i] != NULL)
	{
		cmd_path = ft_strjoin(paths[i], cmd);
		if (cmd_path == NULL)
			return (0);
		result = access(cmd_path, F_OK | X_OK);
		free(cmd_path);
		if (result == 0)
			return (1);
		i = i + 1;
	}
	return (0);
}
